import { Injectable } from '@angular/core';
import { HttpClient } from '../../node_modules/@angular/common/http';
import { Customer } from './customer';
import { Observable } from '../../node_modules/rxjs';
import { Merchant } from './merchant';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http:HttpClient) { }

  private baseUrl = 'http://localhost:1947'

  //private baseUrl2 = 'http://localhost:1947/signupmerchant';
  //private baseUrl1 = 'http://localhost:1947/signinmerchant';

  getAllCustomers(): Observable<any>{
    return this.http.get(`${this.baseUrl}` + `/allCustomer`);
  }

  addCustomer(customer:Customer): Observable<any>{
    return this.http.post(`${this.baseUrl}` + `/create`, customer);
  }







  getAllMerchant(): Observable<any>{
    return this.http.get(`${this.baseUrl}` + `/allMerchant`);
  }
  addMerchant(merchant){
    return this.http.post<Merchant>(`${this.baseUrl}` + `/signupmerchant`, merchant);
  }
  
  
  
  
}
