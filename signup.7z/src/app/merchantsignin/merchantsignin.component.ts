import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '../../../node_modules/@angular/router';
import { Merchant } from '../merchant';

@Component({
  selector: 'app-merchantsignin',
  templateUrl: './merchantsignin.component.html',
  styleUrls: ['./merchantsignin.component.css']
})
export class MerchantsigninComponent implements OnInit {

  allMerchant:Merchant[];

  constructor(private service:CustomerService, private router:Router) { }

  ngOnInit() {
    this.getAll();
  }

 getAll(){
   this.service.getAllMerchant().subscribe(data=>this.allMerchant=data);
 }

 signIn(data){
   for(let i=0;this.allMerchant.length;i++){
     if(data.merchantEmail==this.allMerchant[i].merchantEmail){
       alert(data.merchantEmail)
       if(data.merchantPassword==this.allMerchant[i].merchantPassword){
         alert("welcome");
       }
     }
   }
 }
}
