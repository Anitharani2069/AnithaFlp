import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantsigninComponent } from './merchantsignin.component';

describe('MerchantsigninComponent', () => {
  let component: MerchantsigninComponent;
  let fixture: ComponentFixture<MerchantsigninComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchantsigninComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantsigninComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
