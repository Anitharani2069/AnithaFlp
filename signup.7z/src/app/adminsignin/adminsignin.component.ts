import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-adminsignin',
  templateUrl: './adminsignin.component.html',
  styleUrls: ['./adminsignin.component.css']
})
export class AdminsigninComponent implements OnInit {

  constructor(private route:Router) { }

  ngOnInit() {
  }


  login(data) {
    if (data.adminName === 'capg' && data.adminPassword === 'capg123') {
      alert('Hello Admin');
      this.route.navigate(['/adminPage']);
    } else {
      alert('Invalid Credentials');
    }
  }

}
