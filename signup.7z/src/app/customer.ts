export class Customer {
    customerId:number;
    customerName:string;
    customerMobile:number;
    customerEmail:string;
    customerPassword:string;
    customerWallet:number;
    customerHistory:string;
    customerCartId:number;
}