package com.capgemini.capstore.service;

import java.util.List;

import javax.management.RuntimeErrorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.dao.MerchantRepository;

@Service
public class MerchantService {
	@Autowired MerchantRepository merchantRepo;
	
	public void registerMerchant(Merchant merchant) {
		merchantRepo.save(merchant);
	}
	
	public List<Merchant> getAllMerchant(){
		return  merchantRepo.findAll();
	}
	
	
			
}

