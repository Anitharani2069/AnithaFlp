package com.capgemini.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.service.CustomerServiceInterface;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class CustomerController {
	
	@Autowired
	CustomerServiceInterface service;
	
	
	@GetMapping(value="/allCustomer")
	public List<Customer> allCustomers(){
		System.out.println(service.allCustomers().toString());
		return service.allCustomers();
	}
	
	
	
	@PostMapping(value="/create")
	public void addCustomer(@RequestBody Customer customer) {
		//customer.setCustomerCartId("101");
		//customer.setCustomerHistory("Empty History");
		customer.setCustomerWallet(2000);
		System.out.println(customer);
		service.addCustomer(customer);
	}
	
	@GetMapping
	public Customer customerById(@RequestBody int id) {
		return service.getById(id);
	}
	
	

}
